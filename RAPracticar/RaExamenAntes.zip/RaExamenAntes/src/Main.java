
public class Main{
    public static void iniciar(){
        new AppBanco().ejecutar();
    }
    public static void main(String[] args) {
        iniciar();
    }
}