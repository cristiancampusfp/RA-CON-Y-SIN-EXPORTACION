// Java
/**
 * Clase principal mínima. Solo expone un método para iniciar el programa.
 */
public class Main {

    public static void iniciar() {
        new AppBanco().ejecutar();
    }

    public static void main(String[] args) {
        iniciar();
    }
}
